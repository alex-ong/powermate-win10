from distutils.core import setup

setup(name = "WinUsbPy",
    version = "0.1",
    description = "A python wrapper for WinUsb",
    author = "Felipe Herranz",
    author_email = "felhr85@gmail.com",
    url = "http://felhr85.net",
   
    packages = ['winusbpy'],
   )